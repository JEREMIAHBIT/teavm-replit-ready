import express from "express";
import multer from "multer";
import { exec } from "child_process";
import fs from "fs";
import path from "path";

const app = express();
const upload = multer({ dest: "uploads/" });

app.use(express.static("public"));
fs.mkdirSync("uploads", { recursive: true });
fs.mkdirSync("output", { recursive: true });

app.post("/convert", upload.single("jarfile"), (req, res) => {
  const jarPath = req.file.path;
  const filename = req.file.originalname.replace(".jar", "");
  const outDir = path.resolve("output", filename);
  fs.mkdirSync(outDir, { recursive: true });

  // Replace 'Main' with your actual main class
  const cmd = `java -jar teavm/teavm-cli.jar \
--target wasm \
--main-class Main \
--classpath ${jarPath} \
--debug-info \
--js-output ${outDir}/output.js \
--wasm-output ${outDir}/output.wasm`;

  exec(cmd, (error, stdout, stderr) => {
    if (error) {
      console.error(stderr);
      res.status(500).send(stderr);
      return;
    }

    res.json({
      js: `/output/${filename}/output.js`,
      wasm: `/output/${filename}/output.wasm`
    });

    fs.rmSync(jarPath);
  });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`🚀 TeaVM Converter running on port ${PORT}`));
